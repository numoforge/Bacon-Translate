// Language codes accepted by Google Translate (client=gtx).
const RAW = "af:Afrikaans|sq:Albanian|am:Amharic|ar:Arabic|hy:Armenian|as:Assamese|ay:Aymara|az:Azerbaijani|bm:Bambara|eu:Basque|be:Belarusian|bn:Bengali|bho:Bhojpuri|bs:Bosnian|bg:Bulgarian|ca:Catalan|ceb:Cebuano|zh-CN:Chinese (Simplified)|zh-TW:Chinese (Traditional)|co:Corsican|hr:Croatian|cs:Czech|da:Danish|dv:Dhivehi|doi:Dogri|nl:Dutch|en:English|eo:Esperanto|et:Estonian|ee:Ewe|fil:Filipino|fi:Finnish|fr:French|fy:Frisian|gl:Galician|ka:Georgian|de:German|el:Greek|gn:Guarani|gu:Gujarati|ht:Haitian Creole|ha:Hausa|haw:Hawaiian|he:Hebrew|hi:Hindi|hmn:Hmong|hu:Hungarian|is:Icelandic|ig:Igbo|ilo:Ilocano|id:Indonesian|ga:Irish|it:Italian|ja:Japanese|jv:Javanese|kn:Kannada|kk:Kazakh|km:Khmer|rw:Kinyarwanda|gom:Konkani|ko:Korean|kri:Krio|ku:Kurdish (Kurmanji)|ckb:Kurdish (Sorani)|ky:Kyrgyz|lo:Lao|la:Latin|lv:Latvian|ln:Lingala|lt:Lithuanian|lg:Luganda|lb:Luxembourgish|mk:Macedonian|mai:Maithili|mg:Malagasy|ms:Malay|ml:Malayalam|mt:Maltese|mi:Maori|mr:Marathi|mni-Mtei:Meiteilon (Manipuri)|lus:Mizo|mn:Mongolian|my:Myanmar (Burmese)|ne:Nepali|no:Norwegian|or:Odia (Oriya)|om:Oromo|ps:Pashto|fa:Persian|pl:Polish|pt:Portuguese|pa:Punjabi|qu:Quechua|ro:Romanian|ru:Russian|sm:Samoan|sa:Sanskrit|gd:Scots Gaelic|nso:Sepedi|sr:Serbian|st:Sesotho|sn:Shona|sd:Sindhi|si:Sinhala|sk:Slovak|sl:Slovenian|so:Somali|es:Spanish|su:Sundanese|sw:Swahili|sv:Swedish|tg:Tajik|ta:Tamil|tt:Tatar|te:Telugu|th:Thai|ti:Tigrinya|ts:Tsonga|tr:Turkish|tk:Turkmen|ak:Twi|uk:Ukrainian|ur:Urdu|ug:Uyghur|uz:Uzbek|vi:Vietnamese|cy:Welsh|xh:Xhosa|yi:Yiddish|yo:Yoruba|zu:Zulu";

export const LANGUAGES = RAW.split("|").map((s) => {
  const i = s.indexOf(":");
  return { code: s.slice(0, i), name: s.slice(i + 1) };
});

const ALIASES = { iw: "he", jw: "jv", tl: "fil", zh: "zh-CN", "zh-cn": "zh-CN", "zh-tw": "zh-TW", "zh-hans": "zh-CN", "zh-hant": "zh-TW" };
const BY_CODE = new Map(LANGUAGES.map((l) => [l.code.toLowerCase(), l]));

export function normalizeCode(code) {
  if (!code) return null;
  const c = String(code).trim();
  const alias = ALIASES[c.toLowerCase()];
  if (alias) return alias;
  const hit = BY_CODE.get(c.toLowerCase());
  return hit ? hit.code : c;
}
export const isSupported = (code) => BY_CODE.has(String(code || "").toLowerCase());
export function languageName(code) {
  const n = normalizeCode(code);
  const hit = n && BY_CODE.get(n.toLowerCase());
  return hit ? hit.name : (n || "").toUpperCase();
}
